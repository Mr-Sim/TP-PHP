<?php
  require_once('connexion.php');
  require_once('fonctions.php');

  if(isset($_GET['delete'])){
    $id = $_GET['delete'];
    deleteSalaries($conn,$id);
  }

  if (isset($_POST['update'])){
    updateSalarie($conn,$_POST);
   
  }
  
  if (isset($_POST['ajouter'])){
      ajouterSalaries($conn,$_POST);
  }
  
  $nbSalaries = getNbSalaries($conn);
  $listeSalaries = getAllSalaries($conn);
  $salMoyen = getSalaireMoyen($conn);
  $salMin = getSalaireMin($conn);
  $salMax = getSalaireMax($conn);
  $nbParService = getNbSalariesParService($conn);
  
?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="utf-8" />
  <link rel="stylesheet" href="style.css" />
</head>




<table border=2>
  <th>id</th>
  <th>nom</th>
  <th>prenom</th>
  <th>date-naissance</th>
  <th>date-embauche</th>
  <th>salaire</th>
  <th>service</th>
  <th>delete</th>
  <th>update</th>
<?php foreach ($listeSalaries as $cle=>$valeur): ?>
    <tr>
	<?php foreach ($valeur as $val): ?>
		<td><?php echo $val ?></td>
		
	<?php endforeach; ?>
	<td><a href=listeSalaries2.php?delete=<?php echo $valeur['idsalaries'] ?> 
       onClick="return(confirm('Etes-vous sûr de vouloir supprimer <?php echo $valeur['nom'] ?> ?'));">delete</a></td>
	<td><a href=form.php?id=<?php echo $valeur['idsalaries'] ?> >update</a></td>    
    </tr>
 <?php endforeach; ?>
</table>

<a href=form1.php>Ajouter un salarié</a>

<p>Nombre de salariés : <?= $nbSalaries ; ?> </p>
<p>Salaire moyen : <?= round($salMoyen) ; ?> </p>
<p>Salaire minimum : <?= $salMin ; ?> </p>
<p>Salaire maximum : <?= $salMax ; ?> </p>
<p> nombre de salariés par service : </p>
<?php foreach ($nbParService as $cle=>$valeur): ?>
	<ul>
	<?php foreach ($valeur as  $val): ?>
		<?= $val ?>
    
	<?php endforeach; ?>
	</ul>
 <?php endforeach; ?>



