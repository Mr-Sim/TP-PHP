<?php



function getNbSalaries($conn){
  $req = "SELECT count(*) FROM salaries ;";
  $result = mysqli_query($conn,$req) or die (mysqli_error($conn));
  $ligne=mysqli_fetch_array($result);
 
  return $ligne[0];
}

function getSalaireMin($conn){
 
  $req = "SELECT MIN(salaire) FROM salaries ;";
  $result = mysqli_query($conn,$req) or die (mysql_error($conn));
  $ligne=mysqli_fetch_array($result);

 return $ligne[0];
}


function getSalaireMoyen($conn){
 
  $req = "SELECT AVG(salaire) FROM salaries ;";
  $result = mysqli_query($conn,$req) or die (mysql_error($conn));
  $ligne=mysqli_fetch_array($result);

 return $ligne[0];
}

function getSalaireMax($conn){
  
  $req = "SELECT MAX(salaire) FROM salaries ;";
  $result = mysqli_query($conn,$req) or die (mysqli_error($conn));
  $ligne=mysqli_fetch_array($result);

 return $ligne[0];
}

function getNbSalariesParService($conn){
    
    $nbParService = array(); 
    $requete = 'SELECT service,count(*) as nb FROM salaries group by service'; 
    $result = mysqli_query( $conn,$requete ) or die( mysqli_error($conn) ); 

    while($ligne = mysqli_fetch_assoc($result)) { 
	 $nbParService[]=$ligne; 
    } 
 
    return $nbParService; 
}






function getAllSalaries($conn){
   
    $listeSalaries = array(); 
    $requete = 'SELECT * FROM salaries '; 
    $result = mysqli_query($conn, $requete ) or die( mysqli_error($conn) ); 

    while($ligne = mysqli_fetch_assoc($result)) { 
	 $listeSalaries[]=$ligne; 
    } 
    return $listeSalaries; 
}

function getSalarie($conn,$id){

    
    $requete = "SELECT * FROM salaries where idsalaries = $id"; 
    $result = mysqli_query( $conn,$requete ) or die( mysqli_error($conn) ); 

    $salarie = mysqli_fetch_assoc($result);
    return $salarie; 
}




function deleteSalaries($conn,$id){
      
      $req3 = "delete from salaries where idsalaries = $id ;";
       mysqli_query($conn,$req3) or die (mysqli_error($conn));
}

function updateSalarie($conn,$params){
  
  $nom = $params['nom'];
  $prenom = $params['prenom'];
  $dateNaissance = $params['dateNaissance'];
  $dateEmbauche = $params['dateEmbauche'];
  $salaire = $params['salaire'];
  $service = $params['service'];
  $id = $params['id'];
  $requete = "update salaries set nom='$nom',prenom='$prenom',date_naissance='$dateNaissance',date_embauche='$dateEmbauche',
              salaire=$salaire,service='$service' where idsalaries=$id";
  mysqli_query($conn,$requete) or die (mysqli_error($conn));

}


function ajouterSalaries($conn,$tab){
   
     // $nom =  (isset($tab['nom']) && !empty($tab['nom'])) ? $tab['nom']: header('Location:form1.php?message=remplir nom');
     if(isset($tab['nom']) && !empty($tab['nom']))
	$nom = $tab['nom'];
     else 
	header('Location:form1.php?message=remplir nom');
     $prenom = $tab['prenom'];
     $dateNaissance = $tab['dateNaissance'];
     $dateEmbauche = $tab['dateEmbauche'];
     $salaire = $tab['salaire'];
     $service = $tab['service'];
     $requete = "INSERT INTO salaries values('','$nom','$prenom','$dateNaissance','$dateEmbauche',$salaire,'$service')";
     
     mysqli_query($conn,$requete) or die(mysqli_error($conn));
}



?>
