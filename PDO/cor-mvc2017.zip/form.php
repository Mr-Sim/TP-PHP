<?php
  require_once('connexion.php');
  require_once('fonctions.php');

  $salarie = getSalarie($conn,$_GET['id']);
  
?>

<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="utf-8" />
  <link rel="stylesheet" href="style.css" />
  <link href="datepicker.css" rel="stylesheet" type="text/css"/>	
	<script src="http://code.jquery.com/jquery-1.9.1.js"></script>
        <script src="http://code.jquery.com/ui/1.10.3/jquery-ui.js"></script>
	<script type="text/javascript">
		$(function(){
			$('#datenaiss,#dateembauche').datepicker({
				inline: true,
				showOtherMonths: true,
				changeMonth: true,
				changeYear: true,
                                yearRange: "-100:+0",
				maxDate: '0',
				dateFormat: 'yy-mm-dd',
				dayNamesMin: ['Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam', 'Dim'],
                                monthNames: ['Janvier','F&eacute;vrier','Mars','Avril','Mai','Juin',
        'Juillet','Ao&ucirc;t','Septembre','Octobre','Novembre','D&eacute;cembre'],
				maxDate : '-18Y',
   				minDate: '-100Y',
				
			});
		});
	</script>
  
</head>
	<form method="post" action="listeSalaries2.php">
     		Nom : <input type="text" name="nom" value="<?=  $salarie['nom'] ?> "><br>
     		Prenom : <input type="text" name="prenom" value="<?= $salarie['prenom']  ?> "><br>
		Date Naissance : <input type="text" id="datenaiss" name="dateNaissance" value="<?= $salarie['date_naissance'] ?> "><br>
		Date Embauche : <input type="text" id="dateembauche"name="dateEmbauche" value="<?= $salarie['date_embauche'] ?> "><br>
		salaire : <input type="text" name="salaire" value="<?= $salarie['salaire'] ?> "><br>
		service :<br> <input type="radio" name="service" value="commercial" > commercial<br>
		              <input type="radio" name="service" value="comptable" > comptable<br>   
			      <input type="radio" name="service" value="informatique" >informatique<br> 

		
		
		<input type="hidden" name="id" value="<?= $salarie['idsalaries'] ?> "><br>
   		<input type="submit" name="update" value="Update">
		  
	</form>
