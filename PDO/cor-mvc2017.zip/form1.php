<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="utf-8" />
  <link rel="stylesheet" href="style.css" />
  <link href="datepicker.css" rel="stylesheet" type="text/css"/>	
	<script src="http://code.jquery.com/jquery-1.9.1.js"></script>
        <script src="http://code.jquery.com/ui/1.10.3/jquery-ui.js"></script>
	<script type="text/javascript">
		$(function(){
			$('#datenaiss').datepicker({
				inline: true,
				showOtherMonths: true,
				changeMonth: true,
				changeYear: true,
                                yearRange: "-100:+0",
				maxDate: '0',
				dateFormat: 'yy-mm-dd',
				dayNamesMin: ['Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam', 'Dim'],
                                monthNames: ['Janvier','F&eacute;vrier','Mars','Avril','Mai','Juin',
        'Juillet','Ao&ucirc;t','Septembre','Octobre','Novembre','D&eacute;cembre'],
				maxDate : '-18Y',
   				minDate: '-100Y',
				
			});

			$('#dateembauche').datepicker({
				inline: true,
				showOtherMonths: true,
				changeMonth: true,
				changeYear: true,
                                yearRange: "-100:+0",
				maxDate: '0',
				dateFormat: 'yy-mm-dd',
				dayNamesMin: ['Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam', 'Dim'],
                                monthNames: ['Janvier','F&eacute;vrier','Mars','Avril','Mai','Juin',
        'Juillet','Ao&ucirc;t','Septembre','Octobre','Novembre','D&eacute;cembre'],
				minDate: '-10',
				maxDate : '+10',
				
			});


		});
	</script>
  
  
</head>
<?php 
  if(isset($_GET['message'])){
	$message =$_GET['message'];
        echo $message;
   }
?>
	<form method="post" action="listeSalaries2.php?ajouter">
     		Nom : <input type="text" name="nom"  ><br>
     		Prenom : <input type="text" name="prenom" ><br>
		Date Naissance : <input readonly="readonly" type="text" id="datenaiss" name="dateNaissance" ><br>
		Date Embauche : <input type="text" id="dateembauche" name="dateEmbauche" ><br>
		salaire : <input type="text" name="salaire" ><br>
		service :<br> <input type="radio" name="service" value="commercial" > commercial<br>
		              <input type="radio" name="service" value="comptable" > comptable<br>   
			      <input type="radio" name="service" value="informatique" >informatique<br> 

		<input type="submit" name="ajouter" value="ajouter">
	</form>
